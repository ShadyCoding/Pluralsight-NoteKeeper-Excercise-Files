To use the adb utility from the command line, you'll need to add the Android SDK's platform-tools folder to your path.

First find your Android SDK folder
1. Open Android Studio
2. From the Android Studio menu, choose Tools | Android | SDK Manager
3. In the dialog that opens, you'll see the SDK Location displayed near the top

Now set your path to include the platform-tools folder within the SDK Location.

  For example, my SDK Location is C:\Users\Jim\AppData\Local\Android\Sdk

  So I set my path to include C:\Users\Jim\AppData\Local\Android\Sdk\platform-tools